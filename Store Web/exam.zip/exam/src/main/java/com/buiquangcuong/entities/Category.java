package com.buiquangcuong.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "category")
public class Category {

    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name", length = 100, nullable = false)
    private String name;

    @OneToMany(mappedBy = "category")
    List<Product> products;

    @PreRemove
    void setForeignKeyNull() {
        List<Product> pros = this.getProducts();
        for (Product p : pros) {
            p.setCategory(null);
        }
    }
}
