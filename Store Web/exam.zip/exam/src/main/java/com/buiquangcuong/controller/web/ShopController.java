package com.buiquangcuong.controller.web;

import com.buiquangcuong.entities.Product;
import com.buiquangcuong.entities.ProductDetail;
import com.buiquangcuong.entities.ProductImages;
import com.buiquangcuong.entities.Tag;
import com.buiquangcuong.model.ProductFilterModel;
import com.buiquangcuong.repositories.ImageRepository;
import com.buiquangcuong.repositories.ProductDetailRepository;
import com.buiquangcuong.repositories.ProductRepository;
import com.buiquangcuong.repositories.TagRepository;
import com.buiquangcuong.services.ProductService;
import com.buiquangcuong.services.WebService;
import org.javatuples.Pair;
import org.javatuples.Triplet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class ShopController {

    /*
     * filter model in session
     */
    public final static String FILTER_MODEL = "filterModel";
    @Autowired
    WebService webService;

    @Autowired
    ImageRepository imageRepository;

    @Autowired
    ProductService productService;

    @Autowired
    HttpServletRequest request;

    @Autowired
    ProductDetailRepository proDetailRepository;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    TagRepository tagRepository;

    @RequestMapping(value = "/shop", method = RequestMethod.GET)
    public String index(Model model) throws Exception {

        request.getSession().removeAttribute(FILTER_MODEL);
//		model.addAttribute("collections",webService.getAllCollection());
//		model.addAttribute("categories",webService.getAllCategory());
//		model.addAttribute("products",webService.getAllProduct(PageRequest.of(0, WebConstants.NUM_OF_PRODUCTS)));
//		model.addAttribute("size",webService.getAllProduct().size());
//		model.addAttribute("currentPage",1);
//		model.addAttribute("totalPage",Math.ceil((double)webService.getAllProduct().size()/WebConstants.NUM_OF_PRODUCTS));
//		return "front-end/shop";
        return "forward:/shop/search?page=1";
    }

    @RequestMapping(value = "/shop/search", method = RequestMethod.GET)
    public String shopSearch(Model model) throws Exception {
        try {
            HttpSession session = request.getSession();
            String favorite = request.getParameter("favorite");
            ProductFilterModel proFilter = null;
            if (session.getAttribute(FILTER_MODEL) != null) {
                proFilter = (ProductFilterModel) session.getAttribute(FILTER_MODEL);
            } else {
                proFilter = new ProductFilterModel();
                proFilter.setCurrenPage(1);
                session.setAttribute(FILTER_MODEL, proFilter);
            }

            String strCategoryId = request.getParameter("categoryid");
            String strCollectionId = request.getParameter("collectionid");
            String strCurrentPage = request.getParameter("page");
            String strPriceBegin = request.getParameter("priceBegin");
            String strPriceEnd = request.getParameter("priceEnd");
            String strSort = request.getParameter("sort");

            if (strCategoryId != null) {
                proFilter.setCategoryId(Integer.valueOf(strCategoryId));
                proFilter.setSort(null);
            }
            if (strCollectionId != null) {
                proFilter.setCollectionId(Integer.valueOf(strCollectionId));
                proFilter.setSort(null);
            }
            if (strPriceBegin != null) {
                proFilter.setBeginPrice(Float.valueOf(strPriceBegin));
                proFilter.setSort(null);
            }
            if (strPriceEnd != null)
                proFilter.setEndPrice(Float.valueOf(strPriceEnd));
            if (strCurrentPage != null)
                proFilter.setCurrenPage(Integer.valueOf(strCurrentPage));
            if (strSort != null)
                proFilter.setSort(strSort);

            // use pair để trả về dữ liệu cho client
            List<Product> products = productService.filterProduct(proFilter);
            List<Pair<Product, List<ProductImages>>> pairs = new ArrayList<>();
            Pair<Integer, String> pair ;

            products.forEach(p -> {
                List<ProductImages> images = imageRepository.findByProductId(p.getId());
                pairs.add(Pair.with(p, images));
            });

            model.addAttribute("products", pairs);
            model.addAttribute("size", proFilter.getSize());
            model.addAttribute("totalPage", proFilter.getTotalPage());

            model.addAttribute("categories", webService.getAllCategory());

            model.addAttribute("currentPage", proFilter.getCurrenPage());
            model.addAttribute("currentCategoryId", proFilter.getCategoryId());
            model.addAttribute("currentCollectionId", proFilter.getCollectionId());
            model.addAttribute("cate", "shop");
            model.addAttribute("price", proFilter.getBeginPrice());

            return "front-end/shop";
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    @RequestMapping(value = {"/shop-details/{id}"}, method = RequestMethod.GET)
    public String index(@PathVariable("id") Integer id, ModelMap model) throws Exception {
        try {
            Product product = productRepository.findById(id).get();
            List<ProductImages> proImages = imageRepository.findByProduct(product);
            HashMap<Integer, ProductImages> images = new HashMap<>();
            for (int i = 0; i < proImages.size(); ++i) {
                images.put(i + 1, proImages.get(i));
            }
            ProductDetail detail = proDetailRepository.findByProductId(product.getId()).get(0);
            // dùng triplet để đưa dữ liệu về client
            Triplet<Product, HashMap<Integer, ProductImages>, ProductDetail> productResp = new Triplet<>(product, images, detail);
            model.addAttribute("product", productResp);
            model.addAttribute("keyset", images.keySet());
            model.addAttribute("cate", "shop");
            return "front-end/shop-details";
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    @RequestMapping(value = "/shop/search", method = RequestMethod.POST)
    public String search(Model model) throws Exception {
        try {
            HttpSession session = request.getSession();
            ProductFilterModel proFilter = null;
            if (session.getAttribute(FILTER_MODEL) != null) {
                proFilter = (ProductFilterModel) session.getAttribute(FILTER_MODEL);
            } else {
                proFilter = new ProductFilterModel();
                session.setAttribute(FILTER_MODEL, proFilter);
            }
            String keyword = request.getParameter("keyword").toUpperCase();
            proFilter.resetFilter();

            List<Product> products = productRepository.findAll();
            List<Triplet<Product, String, String>> triplets = new ArrayList<>();

            products.forEach(product -> {
                List<Tag> tags = tagRepository.findByProductId(product.getId());
                Triplet<Product, String, String> item =
                        new Triplet<>(product, tags.get(0).getTag(), tags.get(1).getTag());
                triplets.add(item);
            });

            List<Product> productResp = triplets.stream()
                    .filter(item -> item.contains(keyword))
                    .map(Triplet::getValue0)
                    .collect(Collectors.toList());

            List<Pair<Product, List<ProductImages>>> pairs = new ArrayList<>();

            productResp.forEach(p -> {
                List<ProductImages> images = imageRepository.findByProductId(p.getId());
                pairs.add(Pair.with(p, images));
            });

            model.addAttribute("products", pairs);
            model.addAttribute("size", proFilter.getSize());
            model.addAttribute("totalPage", proFilter.getTotalPage());

            model.addAttribute("categories", webService.getAllCategory());

            model.addAttribute("currentPage", proFilter.getCurrenPage());
            model.addAttribute("currentCategoryId", proFilter.getCategoryId());
            model.addAttribute("currentCollectionId", proFilter.getCollectionId());
            model.addAttribute("cate", "shop");

            return "front-end/shop";
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
