package com.buiquangcuong.services;

import com.buiquangcuong.WebConstants;
import com.buiquangcuong.entities.Product;
import com.buiquangcuong.entities.ProductDetail;
import com.buiquangcuong.entities.ProductImages;
import com.buiquangcuong.model.ProductFilterModel;
import com.buiquangcuong.repositories.ImageRepository;
import com.buiquangcuong.repositories.ProductDetailRepository;
import com.buiquangcuong.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    EntityManager entityManager;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    ImageRepository imageRepository;

    @Autowired
    ProductDetailRepository detailRepository;

    public ProductService() {
    }

    @SuppressWarnings("unchecked")
    public List<Product> filterProduct(final ProductFilterModel proFilter) {
        StringBuilder sql = new StringBuilder("FROM Product p WHERE 1=1");
        if (proFilter.getCategoryId() != null)
            sql.append(" AND p.category.id = " + proFilter.getCategoryId());
        if (proFilter.getCollectionId() != null)
            sql.append(" AND p.collection.id = " + proFilter.getCollectionId());
        if (proFilter.getBeginPrice() != null)
            sql.append(" AND p.price >= " + proFilter.getBeginPrice());
        if (proFilter.getEndPrice() != null && proFilter.getEndPrice() > proFilter.getBeginPrice())
            sql.append(" AND p.price <= " + proFilter.getEndPrice());

        if (proFilter.getSort() != null)
            sql.append(" ORDER BY p.price " + proFilter.getSort());

        Query query = entityManager.createQuery(sql.toString());
        if (proFilter.getCurrenPage() == 1) {
            List<Product> initializeProducts = query.getResultList();
            proFilter.setSize(initializeProducts.size());
            proFilter.setTotalPage((int) Math.ceil((double) proFilter.getSize() / WebConstants.NUM_OF_PRODUCTS));
        }
        query.setFirstResult((proFilter.getCurrenPage() - 1) * WebConstants.NUM_OF_PRODUCTS);
        query.setMaxResults(WebConstants.NUM_OF_PRODUCTS);
        return query.getResultList();
    }

    private boolean isEmptyUploadFile(MultipartFile[] images) {
        if (images == null || images.length <= 0)
            return true;
        if (images.length == 1 && images[0].getOriginalFilename().isEmpty())
            return true;
        return false;
    }

    @Transactional
    public void save(MultipartFile[] productImages, Product product) throws IllegalStateException, IOException {

        if (product.getId() != null) { // chỉnh sửa

            if (!isEmptyUploadFile(productImages)) { // nếu admin sửa ảnh sản phẩm
                // lấy danh sách ảnh cũ của sản phẩm
                List<ProductImages> oldProductImages = imageRepository.findByProduct(product);

                // xoá ảnh cũ trên vật lí(host)
                for (ProductImages _image : oldProductImages) {
                    new File(WebConstants.IMG_URL + _image.getPath()).delete();
                }

                // xoá ảnh trên database
                imageRepository.deleteAll(oldProductImages);
                for (MultipartFile productImage : productImages) {

                    // lưu vật lí
                    productImage.transferTo(new File(WebConstants.IMG_URL + productImage.getOriginalFilename()));

                    ProductImages _productImages = new ProductImages();
                    _productImages.setPath(productImage.getOriginalFilename());
                    _productImages.setProduct(product);
                    imageRepository.save(_productImages);
                }

            }
            productRepository.save(product);
        } else {
            ProductDetail detail = product.getProductDetail();
            product.setProductDetail(null);
            Product newProduct = productRepository.save(product);
            detail.setProduct(newProduct);
            detailRepository.save(detail);
            if (!isEmptyUploadFile(productImages)) { // có upload ảnh lên.
                for (MultipartFile productImage : productImages) {

                    // lưu vật lí
                    productImage.transferTo(new File(WebConstants.IMG_URL + productImage.getOriginalFilename()));

                    ProductImages _productImages = new ProductImages();
                    _productImages.setPath(productImage.getOriginalFilename());
                    _productImages.setProduct(newProduct);
                    imageRepository.save(_productImages);
                }
            }
        }
    }
}
