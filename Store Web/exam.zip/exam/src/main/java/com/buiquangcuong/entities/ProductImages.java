package com.buiquangcuong.entities;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "products_image")
public class ProductImages {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "path", nullable = false)
    private String path;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;
}
