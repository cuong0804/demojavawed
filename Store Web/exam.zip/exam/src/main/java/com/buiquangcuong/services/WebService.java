package com.buiquangcuong.services;

import com.buiquangcuong.entities.Category;
import com.buiquangcuong.entities.Product;
import com.buiquangcuong.repositories.CategoryRepository;
import com.buiquangcuong.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WebService {

    @Autowired
    ProductRepository productRepository;

    @Autowired
    CategoryRepository categoryRepository;


    public List<Product> getAllProduct() {
        return productRepository.findAll();
    }

    public List<Product> getAllProduct(PageRequest page) {
        return productRepository.findAll(page).getContent();
    }

    public List<Category> getAllCategory() {
        return categoryRepository.findAll();
    }

}
