package com.buiquangcuong.controller.admin;

import com.buiquangcuong.WebConstants;
import com.buiquangcuong.entities.Product;
import com.buiquangcuong.entities.ProductImages;
import com.buiquangcuong.entities.Tag;
import com.buiquangcuong.repositories.CategoryRepository;
import com.buiquangcuong.repositories.ImageRepository;
import com.buiquangcuong.repositories.ProductRepository;
import com.buiquangcuong.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.List;

@Controller
public class AdminProductController {

    @Autowired
    ProductRepository productRepository;

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    ImageRepository imageRepository;

    @Autowired
    ProductService productService;


    @RequestMapping(value = {"/admin/products"}, method = RequestMethod.GET)
    public String index(final ModelMap model, final HttpServletRequest request, final HttpServletResponse Response)
            throws Exception {
        List<Product> products = productRepository.findAll();
        model.addAttribute("products", products);
        return "back-end/view_products";
    }

    @RequestMapping(value = {"/admin/product-add/{id}"}, method = RequestMethod.GET)
    public String edit(@PathVariable Integer id, final ModelMap model, final HttpServletRequest request,
                       final HttpServletResponse Response) throws Exception {
        try {
            if (id == null)
                model.addAttribute("product", new Product());
            else {
                Product product = productRepository.getById(Integer.valueOf(id));
                product.setCategory(null);
                model.addAttribute("product", product);
            }

            model.addAttribute("categories", categoryRepository.findAll());
            return "back-end/insert_product";
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    @RequestMapping(value = {"/admin/product-add"}, method = RequestMethod.GET)
    public String add(final ModelMap model, final HttpServletRequest request, final HttpServletResponse Response)
            throws Exception {
        try {
            String id = request.getParameter("id");
            if (id == null)
                model.addAttribute("product", new Product());
            else {
                Product product = productRepository.getById(Integer.valueOf(id));
                product.setCategory(null);
                model.addAttribute("product", product);
            }

            model.addAttribute("categories", categoryRepository.findAll());
            return "back-end/insert_product";
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    @RequestMapping(value = {"/admin/product-delete/{id}"}, method = RequestMethod.GET)
    public String deleteProduct(@PathVariable("id") Integer id, final ModelMap model, final HttpServletRequest request,
                                final HttpServletResponse response) throws Exception {
        try {
            Product product = productRepository.getById(id);
            List<ProductImages> images = product.getProductImages();
            for (ProductImages pi : images) {
                File file = new File(WebConstants.IMG_URL + pi.getPath());
                file.delete();
            }
            imageRepository.deleteAll(images);

            productRepository.deleteById(id);
            return "redirect:/admin/products";
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    @RequestMapping(value = {"/admin/product-add"}, method = RequestMethod.POST)
    public String saveOrUpdateProduct(@RequestParam("product_images") MultipartFile[] productImages,
                                      @ModelAttribute("product") Product product, final ModelMap model, final HttpServletRequest request,
                                      final HttpServletResponse response) throws Exception {
        try {
            String stag1 = request.getParameter("tag1");
            String stag2 = request.getParameter("tag2");
            Tag tag1 = new Tag();
            tag1.setTag(stag1);
            Tag tag2 = new Tag();
            tag2.setTag(stag2);
            product.getTags().add(tag1);
            product.getTags().add(tag2);
            productService.save(productImages, product);
            return "redirect:/admin/products";
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
