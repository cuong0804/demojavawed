package com.buiquangcuong;

public class WebConstants {
	/*
	 * số sản phẩm hiện trên một trang
	 */
	public static final int NUM_OF_PRODUCTS = 6;
	
	/*
	 * tên session thực hiện công cụ tìm kiếm 
	 */
	public static final String SEARCH_MODEL = "searchModel";
	
	/*
	 * mail is used to send mail
	 */
	public static final String MYMAIL = "changtrai242001@gmail.com";
	
	/*
	 * location saves images
	 */
	public static final String IMG_URL = "/home/linhvu/Project/exam/src/main/resources/META-INF/upload";
}
